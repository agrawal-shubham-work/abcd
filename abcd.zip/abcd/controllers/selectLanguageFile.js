exports.selectLanguage = (language, field) => {
  const file = require(`../messageLanguage/language_${language}`);
  return file.message[field];
};
