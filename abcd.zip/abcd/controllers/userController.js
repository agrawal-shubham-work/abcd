const db = require("../database");
const AppError = require("../utils/appError");
const jwt = require("jsonwebtoken");
const catchAsync = require("../utils/catchAsync");
const bcrypt = require("bcryptjs");
const languageController = require("./selectLanguageFile");
const { QueryTypes } = require("sequelize");

const includeFields = ["name", "email"];

checkPassword = async (enteredPassword, userPassword) => {
  return await bcrypt.compare(enteredPassword, userPassword);
};

createAndSendJWTToken = (user, code, req, res) => {
  const token = jwt.sign({ id: user._id }, process.env.SECRET_KEY, {
    expiresIn: process.env.EXPIRES_IN,
  });

  res.status(code).json({ status: "success", token, data: user });
};

exports.getLanguageId = catchAsync(async (req, res, next) => {
  const userLang = req.headers.lang || "en";

  const id = await db.sequelize.query(
    `SELECT * from languages WHERE language_name = ?`,
    { replacements: [userLang], type: QueryTypes.SELECT }
  );

  if (id.length === 0) return next(new AppError("Language not found", 400));

  req.language = { name: userLang, id: id[0].language_id };

  next();
});

exports.signup = catchAsync(async (req, res, next) => {
  if (!req.body.email || !req.body.password)
    return next(new AppError("Required fields are missing", 400));

  const user = await db.users.create(req.body);

  Object.keys(user.dataValues).forEach((item) => {
    if (!includeFields.includes(item)) delete user.dataValues[item];
  });

  res.status(200).json(user);
});

exports.createProfile = async (req, res, next) => {
  const t = await db.sequelize.transaction();

  try {
    if (!req.body.userId) return next(new AppError("User id is required", 400));

    const user = await db.users.findOne({ where: { id: req.body.userId } });

    if (!user) return next(new AppError("User not found", 400));

    if (!req.body.nameArray)
      return next(new AppError("Names are required", 400));

    let data = [];

    req.body.nameArray.forEach((item) => {
      if (!item.name) {
        throw new AppError(
          languageController.selectLanguage(item.lang, "nameMissing"),
          400
        );
      }

      data.push({
        user_id: req.body.userId,
        language_id: item.lang_id,
        name: item.name,
      });
    });

    const createProfile = await db.userProfiles.bulkCreate(data, {
      transaction: t,
    });

    await t.commit();

    res.status(200).json(createProfile);
  } catch (e) {
    await t.rollback();
    next(e);
  }
};

exports.login = catchAsync(async (req, res, next) => {
  let { email, password } = req.body;
  if (!email || !password)
    return next(
      new AppError(
        languageController.selectLanguage(
          req.language.name,
          "emailPasswordMissing"
        ),
        400
      )
    );

  const user = await db.users.findOne({ where: { email: email } });

  if (!user || !(await checkPassword(password, user.password))) {
    return next(
      new AppError(
        languageController.selectLanguage(
          req.language.name,
          "emailPasswordIncorrect"
        ),
        400
      )
    );
  }

  createAndSendJWTToken(user, 200, req, res);
});

exports.getAllUserWithProfile = catchAsync(async (req, res, next) => {
  const data = await db.users.findAll({
    attributes: ["email", "mobile"],
    include: {
      model: db.userProfiles,
      attributes: ["name"],
      where: { language_id: req.language.id },
      required: false,
    },
  });

  res.status(200).json(data);
});
