module.exports = (fn) => (req, res, next) =>
  fn(req, res, next).catch((e) => {
    console.log(req.transaction);
    if (req.transaction) req.transaction.rollBack();
    next(e);
  });
