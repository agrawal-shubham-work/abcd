const express = require("express");
const cookieParser = require("cookie-parser");
const mongoSanitize = require("express-mongo-sanitize");

const userRoute = require("./routes/userRoute");
const globalErrorHandle = require("./utils/globalErrorHandler");

const app = express();

app.enable("trust proxy");

app.use(express.json({ limit: "10kb" }));

app.use(express.urlencoded({ extended: true, limit: "10kb" }));

app.use(cookieParser());

app.use(mongoSanitize());

app.use("/api/user", userRoute);
app.all("*", (req, res, next) => {
  console.log(req.url);
  res.status(200).send("OK");
});

app.use(globalErrorHandle);

module.exports = app;
