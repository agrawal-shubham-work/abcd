const bcrypt = require("bcryptjs");

module.exports = (sequelize, DataTypes) => {
  const metaSpecialityModel = sequelize.define(
    "meta_speciality",
    {
      meta_speciality_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        unique:true
      },
    },
    { freezeTableName: true }
  );
  return metaSpecialityModel;
};
