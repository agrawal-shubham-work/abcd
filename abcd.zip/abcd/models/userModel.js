const bcrypt = require("bcryptjs");

module.exports = (sequelize, DataTypes) => {
  const Users = sequelize.define(
    "users",
    {
      profile_image: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      mobile: {
        type: DataTypes.BIGINT(10),
        allowNull: false,
        validate: {
          mobileValidation(value) {
            if (value.toString().length !== 10) {
              throw new Error('Invalid mobile number');
            }
          },
        },
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          isEmail: {
            msg: "Enter a valid mail address",
          },
        },
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          len: [8, 28],
        },
      },
    },
    {
      paranoid: true,
      hooks: {
        beforeCreate: async (users, option) => {
          const hashPassword = await bcrypt.hash(users.password, 12);
          users.password = hashPassword;
        },
      },
    }
  );
  return Users;
};
