module.exports = (sequelize, DataTypes) => {
  const UserProfile = sequelize.define(
    "userProfiles",
    {
      user_id: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      language_id: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    { paranoid: true }
  );
  return UserProfile;
};
