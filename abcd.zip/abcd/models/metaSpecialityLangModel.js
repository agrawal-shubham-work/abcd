const bcrypt = require("bcryptjs");

module.exports = (sequelize, DataTypes) => {
  const metaSpecialityLangModel = sequelize.define(
    "meta_speciality_language",
    {
      meta_speciality_language_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        unique: true,
      },
      meta_speciality_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      language_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    { freezeTableName: true }
  );
  return metaSpecialityLangModel;
};
