const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");

router.post("/signup", userController.signup);
router.post("/createProfile", userController.createProfile);
router.post("/login", userController.getLanguageId, userController.login);
router.get(
  "/getAll",
  userController.getLanguageId,
  userController.getAllUserWithProfile
);

module.exports = router;
