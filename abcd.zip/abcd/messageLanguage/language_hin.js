exports.message = {
  emailPasswordMissing: "कृपया ईमेल और पासवर्ड प्रदान करें",
  emailPasswordIncorrect: "गलत ईमेल या पासवर्ड",
  nameMissing: "नाम आवश्यक फ़ील्ड है।",
};
