exports.message = {
  emailPasswordMissing: "Please provide email and password",
  emailPasswordIncorrect: "Incorrect email or password",
  nameMissing: "Name is required field.",
};
