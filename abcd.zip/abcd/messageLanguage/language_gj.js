exports.message = {
  emailPasswordMissing: "કૃપા કરીને ઇમેઇલ અને પાસવર્ડ આપો",
  emailPasswordIncorrect: "ખોટો ઇમેઇલ અથવા પાસવર્ડ",
  nameMissing: "નામ આવશ્યક ક્ષેત્ર છે.",
};
