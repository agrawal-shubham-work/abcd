const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize(
  process.env.DATABASE,
  process.env.USERNAME,
  process.env.PASSWORD,
  { host: "localhost", dialect: "mysql" }
);

sequelize
  .authenticate()
  .then(() => console.log("Connected"))
  .catch((e) => console.log(e));

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.users = require("../models/userModel")(sequelize, DataTypes);
db.userProfiles = require("../models/userProfileModel")(sequelize, DataTypes);
db.metaSpeciality = require("../models/metaSpecialityModel")(
  sequelize,
  DataTypes
);
db.metaSpecialityLang = require("../models/metaSpecialityLangModel")(
  sequelize,
  DataTypes
);

db.users.hasMany(db.userProfiles, { foreignKey: "user_id" });

db.userProfiles.belongsTo(db.users, { foreignKey: "user_id" });

db.metaSpeciality.hasMany(db.metaSpecialityLang, {
  foreignKey: "meta_speciality_id",
});

db.metaSpecialityLang.belongsTo(db.metaSpeciality, {
  foreignKey: "meta_speciality_id",
});



db.sequelize
  .sync()
  .then(() => console.log("resync"))
  .catch((e) => console.log(e));

module.exports = db;
